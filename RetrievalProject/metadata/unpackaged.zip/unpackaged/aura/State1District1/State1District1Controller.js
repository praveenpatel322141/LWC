({
	handlingLowPComplaints : function(component, event, helper) {
		alert("Hi");
        //console.log("LP Message Received");
        var MessageReceived = event.getParam("complainMessage");
        //consile.log("MessageReceived");
	}
})