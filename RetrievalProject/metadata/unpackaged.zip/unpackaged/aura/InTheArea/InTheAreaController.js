({
    doInit : function(component, event, helper) {
                                helper.getLocalList(component);
                },
   
    updateSearch : function(component, event, helper){
        helper.getLocalList(component);
    }
})