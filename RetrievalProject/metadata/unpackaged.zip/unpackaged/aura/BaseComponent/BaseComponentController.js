({
    doInit: function(cmp) {
       alert('Hi');
    }
})